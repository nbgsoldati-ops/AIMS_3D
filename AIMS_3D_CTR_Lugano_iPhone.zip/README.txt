AIMS 3D - ricostruzione CTR da screenshot, non georeferenziata e non idonea a uso ATC. Per interattivita pubblicare index.html via HTTPS e aprire in Safari. Nessuna dipendenza esterna.
